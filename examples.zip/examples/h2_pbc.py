# Input file
#
# Molecule to run procedure on
molecule = "h2_example_pbc"
#
# Name of the output file
output_file = "h2_example_pbc_al" 
#
#2-electron integrals baf file
eri = "h2_2eri" 
#
#Path to scratch directory
scratch = "/Users/marco/scratch" 
#
# Path to gauopen directory
path_gauopen = "/Volumes/gaussian/gdv_j30p/" 
#
# Memory limit (GB) for calculations on Linux platforms
memory = 100 
#
# Energy Convergence Threshold (a.u.)
ThrE = 1e-8
#
# Amplitude Convergence Threshold 
ThrA = 1e-6
#
# Maximum number of iterations
MaxIt = 1000
#
# Perturbation frequencies in nm
WLlist = [300]
#
# Maximum dimension of DIIS extrapolation subspace
MaxD = 6
#
# Extrapolation frequency for DIIS
RepD = 5 
#
# Perturbation type
PertType = "DipE"
#
# Translation vector (Ang) for PBC calculations 
tv = [3.0,0.0,0.0] 
#
# Frozen core approximation
FreezeCore = True 


