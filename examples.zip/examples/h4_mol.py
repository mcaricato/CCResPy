# Input file
#
# Molecule to run procedure on
molecule = "h4_sto3g_mol"
#
# Name of the output file
output_file = "h4_example_mol_orv" 
#
#2-electron integrals baf file
eri = "h4_sto3g_mol" 
#
#Path to scratch directory
scratch = "/Users/marco/scratch" 
#
# Path to gauopen directory
path_gauopen = "/Volumes/gaussian/gdv_j30p/" 
#
# Memory limit (GB) for calculations on Linux platforms
memory = 100 
#
# Energy Convergence Threshold (a.u.)
ThrE = 1e-8
#
# Amplitude Convergence Threshold 
ThrA = 1e-6
#
# Maximum number of iterations
MaxIt = 1000
#
# Perturbation frequencies in nm
WLlist = [1000]
#
# Maximum dimension of DIIS extrapolation subspace
MaxD = 6
#
# Extrapolation frequency for DIIS
RepD = 5 
#
# Perturbation type
PertType = "OR_V"
#
# Translation vector (Ang) for PBC calculations 
#tv = [4.0,0.0,0.0] 
#
# Frozen core approximation
FreezeCore = True 


